package Assignment_4;

public class TestTriangle {
	public static void main(String[] args) {

		Triangle triangle = new Triangle(3, 4, 5);

		triangle.findArea();
		triangle.findPerimeter();
	}
}
